import sqlite3
from sqlite3 import Error

def openConnection(_dbFile):
    

    conn = None
    try:
        conn = sqlite3.connect(_dbFile)
        # print("success")
    except Error as e:
        print(e)

    

    return conn

def closeConnection(_conn, _dbFile):
    

    try:
        _conn.close()
        print("success")
    except Error as e:
        print(e)

    


# def createTable(_conn):
#     print("++++++++++++++++++++++++++++++++++")
#     print("Create table")

#     cur = _conn.cursor()

#     print("++++++++++++++++++++++++++++++++++")



# def dropTable(_conn):
#     print("++++++++++++++++++++++++++++++++++")
#     print("Drop tables")

#     cur = _conn.cursor()
#     cur.execute(f"""
#         DROP TABLE account
#         DROP TABLE majors_tabledata
#         DROP TABLE sports
#         DROP TABLE uni_sports
#         DROP TABLE uni_tabledata
#         DROP TABLE unimajor_tabledata
#         DROP TABLE user
#         """
#     )

#     _conn.commit()

#     print("++++++++++++++++++++++++++++++++++")


def printTable(_conn, city, stupop, priv, ):
    print("Printing table")
    curr = _conn.cursor()
    if city != 0:
        curr.execute(f"""SELECT * FROM University
                    WHERE University.city = '{citychoice[0]}'
                    AND University.stpop < {stupop + 10000}
                    AND University.stpop > {stupop - 10000}
                    AND University.public = {priv}""")
        table = curr.fetchall()
        print("\nSchool Name: ", table[0] )
    else:
        curr.execute(f"""SELECT * FROM University
                    WHERE University.stpop < {stupop + 10000}
                    AND University.stpop > {stupop - 10000}
                    AND University.public = {priv}""")
        table = curr.fetchall()
        for i in table:
            print(i)
            counter = counter + 1


def login(_conn):
    i = 0
    while i < 1:
        print("\nLogin first to use search!\n\nUsername:")
        username = input()
        print("\nPassword:")
        password = input()
        curr = _conn.cursor()
        curr.execute(f"""SELECT username, password FROM Account
                        WHERE username = '{username}'
                        AND password = '{password}'""")
        table = curr.fetchall()
        for j in table:
            if (j[0] == username and j[1] == password):
                print("\nLogin Successful")
                i += 1
    
    temp = ""
    while temp != 'START':
        print("\nType START to begin University Search")
        temp = input()

def firstpage(_conn):
    login(_conn)

    print("Welcome to Search. What in specific are you looking for?\n")
    print("""\nWhat college city are you looking for?""")
    curr = _conn.cursor()
    curr.execute("SELECT DISTINCT city FROM University")
    table = curr.fetchall()
    x = 1
    print("0 No City Choice")
    for i in table:
        print(x, i)
        x = x + 1

    city = int(input())
    # print("""\nAvailable Schools""")
    if city != 0:
        citychoice = table[city - 1]
    #     curr.execute(f"""SELECT * FROM University
    #                 WHERE University.city = '{citychoice[0]}'""")

    #     table = curr.fetchall()
    #     for i in table:
    #         print(i)

    #     #What is your perfer CITY population?
    #     #print("What is the minimum city population of preference")
    # else:
    #     curr.execute(f"""SELECT * FROM University""")  
    #     table = curr.fetchall()
    #     for i in table:
    #         print(i)

    #What STUDENT population is a great range for you?
    print("""\nWhat's a good student population for you""")
    stupop = int(input())

    if city != 0:
        curr.execute(f"""SELECT * FROM University
                    WHERE University.city = '{citychoice[0]}'
                    AND University.stpop < {stupop + 10000}
                    AND University.stpop > {stupop - 10000}""")
        table = curr.fetchall()
        tablength = len(table)
        if (tablength == 0):
            print("No Tables Fit Your Requirements, Try Again")
            return 0
        
        # print("""\nAvailable Schools""")
        # for i in table:
        #     print(i)
    else:
        curr.execute(f"""SELECT * FROM University
                    WHERE University.stpop < {stupop + 10000}
                    AND University.stpop > {stupop - 10000}""")
        table = curr.fetchall()
        tablength = len(table)
        if (tablength == 0):
            print("No Tables Fit Your Requirements, Try Again")
            return 0
        
        # print("""\nAvailable Schools""")
        # for i in table:
        #     print(i)


    #Are you looking for a public or private college?
    print("""\nAre you looking for a public or a private school?
            \n 0 Being Private
            \n 1 Being Public\n""")
    priv = int(input())

    counter = 0
    # print("\nAvailable Schools")
    if city != 0:
        curr.execute(f"""SELECT * FROM University
                    WHERE University.city = '{citychoice[0]}'
                    AND University.stpop < {stupop + 10000}
                    AND University.stpop > {stupop - 10000}
                    AND University.public = {priv}""")
        table = curr.fetchall()
        tablength = len(table)
        if (tablength == 0):
            print("No Tables Fit Your Requirements, Try Again")
            return 0
        
        # print("""\nAvailable Schools""")

    else:
        curr.execute(f"""SELECT * FROM University
                    WHERE University.stpop < {stupop + 10000}
                    AND University.stpop > {stupop - 10000}
                    AND University.public = {priv}""")
        table = curr.fetchall()
        tablength = len(table)
        if (tablength == 0):
            print("No Tables Fit Your Requirements, Try Again")
            return 0
        
        # print("""\nAvailable Schools""")
    for i in table:
        # print(i)
        counter = counter + 1

    if(counter == 1):
        print("This School Seems to be a good fit for you!")
        if(table[0][3] == 0):
            print("\nSchool Name: ", table[0][0], 
                "\nCity: ", table[0][1], 
                "\nStudent Population: ", table[0][2], 
                "\nPublic: No",  
                "\nCity Population: ", table[0][4], 
                "\nCost: ", table[0][5])
        else:
            print("\nSchool Name: ", table[0][0], 
                "\nCity: ", table[0][1], 
                "\nStudent Population: ", table[0][2], 
                "\nPublic: Yes",  
                "\nCity Population: ", table[0][4], 
                "\nCost: ", table[0][5])

    #What is your budget for cost of attendance?
    print("\nWhats a good cost of attendance for you?")
    cost = int(input())

    
    print(f"""\nAvailable Schools""")
    if city != 0:
        curr.execute(f"""SELECT * FROM University
                    WHERE University.city = '{citychoice[0]}'
                    AND University.stpop < {stupop + 10000}
                    AND University.stpop > {stupop - 10000}
                    AND University.public = {priv}
                    AND University.cost < {cost + 2000}
                    AND University.cost > {cost - 2000}""")
        table = curr.fetchall()
        tablength = len(table)
        if (tablength == 0):
            print("No Tables Fit Your Requirements, Try Again")
            return 0
        
        # print("""\nAvailable Schools""")
    else:
        curr.execute(f"""SELECT * FROM University
                    WHERE University.stpop < {stupop + 10000}
                    AND University.stpop > {stupop - 10000}
                    AND University.public = {priv}
                    AND University.cost < {cost + 2000}
                    AND University.cost > {cost - 2000}""")
        table = curr.fetchall()
        tablength = len(table)
        if (tablength == 0):
            print("No Tables Fit Your Requirements, Try Again")
            return 0
        
        # print("""\nAvailable Schools""")

    for i in table:
        # print(i)
        counter = counter + 1

    for i in table:
        if(i[3] == 0):
            print("\nSchool Name: ", i[0], 
                "\nCity: ", i[1], 
                "\nStudent Population: ", i[2], 
                "\nPublic: No",  
                "\nCity Population: ", i[4], 
                "\nCost: ", i[5])
        else:
            print("\nSchool Name: ", i[0], 
                "\nCity: ", i[1], 
                "\nStudent Population: ", i[2], 
                "\nPublic: Yes",  
                "\nCity Population: ", i[4], 
                "\nCost: ", i[5])


   # What major are in mostly interested in specific?
    # print("What major are you interested in?")
    # curr.execute("SELECT * FROM Major")
    # table2 = curr.fetchall()
    # x = 1
    # for i in table2:
    #     print(x, i)
    #     x = x + 1
    
    # maj = int(input())
    # majchoice = table2[maj - 1]
    # print(majchoice[0])
    # counter = 0
    # print("\nAvailable Schools")
    # if city != 0:
    #     curr.execute(f"""SELECT * FROM University
    #                 INNER JOIN Uni_majors ON Uni_majors.uniname = University.uniname
    #                 WHERE University.city = '{citychoice[0]}'
    #                 AND University.stpop < {stupop + 10000}
    #                 AND University.stpop > {stupop - 10000}
    #                 AND University.public = {priv}
    #                 AND University.cost < {cost + 2000}
    #                 AND University.cost > {cost - 2000}
    #                 AND majname = '{majchoice}'""")
    #     table = curr.fetchall()
    #     for i in table:
    #         print(i)
    #         counter = counter + 1
    # else:
    #     curr.execute(f"""SELECT * FROM University
    #                 INNER JOIN Uni_majors ON Uni_majors.uniname = University.uniname
    #                 WHERE University.stpop < {stupop + 10000}
    #                 AND University.stpop > {stupop - 10000}
    #                 AND University.public = {priv}
    #                 AND University.cost < {cost + 2000}
    #                 AND University.cost > {cost - 2000}
    #                 AND majname = '{majchoice}'""")
    #     table = curr.fetchall()
    #     for i in table:
    #         print(i)
    #         counter = counter + 1

    #What sport in specfic are you looking for specific?



# def populateTable(_conn):
#     print("++++++++++++++++++++++++++++++++++")
#     print("Populate table")
    
#     cur = _conn.cursor()

#     cur.execute(f"""

#         .mode csv

#         .import ./data/account.csv account

#         .import ./data/majors_tabledata.csv majors_tabledata

#         .import ./data/sports.csv sports

#         .import ./data/uni_sports.csv uni_sports

#         .import ./data/uni_tabledata.csv uni_tabledata

#         .import ./data/unimajor_tabledata.csv

#         .import ./data/user.csv user

#         """
#     )    

#     _conn.commit()

#     print("++++++++++++++++++++++++++++++++++")



def main():
    database = r"project111.1.db"

    conn = openConnection(database)

    # with conn:
        # dropTable(conn)
        # createTable(conn)
        #populateTable(conn)


    # make functions


    firstpage(conn)
    
    #printTable(conn)




    closeConnection(conn, database)


if __name__ == '__main__':
    main()